/-
Copyright (c) 2024 Jannis Limperg. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Jannis Limperg
-/
module

public import Aesop.Stats.Basic
public import Aesop.RulePattern.Cache

public section

set_option linter.missingDocs true

open Lean

namespace Aesop

/-- State of the `BaseM` monad. -/
structure BaseM.State where
  /-- The rule pattern cache. -/
  rulePatternCache : RulePatternCache
  /-- Stats collected during an Aesop call. -/
  stats : Stats
  deriving Inhabited

instance : EmptyCollection BaseM.State :=
  ⟨by refine' { .. } <;> exact ∅⟩

/-- Aesop's base monad. Contains no interesting data, only various caches and
stats. -/
abbrev BaseM := StateRefT BaseM.State MetaM

namespace BaseM

/-- Run a `BaseM` action. -/
protected def run (x : BaseM α) (stats : Stats := ∅) : MetaM (α × Stats) := do
  let (a, s) ← StateRefT'.run x { stats, rulePatternCache := ∅ }
  return (a, s.stats)

instance : MonadHashMapCacheAdapter Expr RulePatternCache.Entry BaseM where
  getCache := return (← get).rulePatternCache.map
  modifyCache f := modify λ s =>
    { s with rulePatternCache.map := f s.rulePatternCache.map }

instance : MonadStats BaseM where
  modifyGetStats f := modifyGet λ s =>
    let (a, stats) := f s.stats
    (a, { s with stats })
  getStats := return (← get).stats
  modifyStats f := modify λ s => { s with stats := f s.stats }

instance : MonadBacktrack Meta.SavedState BaseM where
  saveState := Meta.saveState
  restoreState := (·.restore)

end Aesop.BaseM
