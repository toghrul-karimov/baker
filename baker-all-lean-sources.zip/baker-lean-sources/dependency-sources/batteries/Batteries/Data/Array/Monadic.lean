module

public import Batteries.Recycling.MonadSatisfying.Array

deprecated_module "it is recommended to use Std.Do.Triple instead" (since := "2026-05-10")
